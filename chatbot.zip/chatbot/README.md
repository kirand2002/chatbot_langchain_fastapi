# Classroom Chat: React + FastAPI + Ollama

## Prerequisites
- Python 3.10+, Node 18+
- Ollama running with the model pulled: `ollama pull llama3.2:latest`

## Run the backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## Run the frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173
